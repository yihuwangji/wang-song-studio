@echo off
chcp 65001 >nul
set SCRIPT=%~dp0Start-Fenshenyun-Windows-Player.ps1
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT%"
pause
