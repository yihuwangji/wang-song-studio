$ErrorActionPreference = "Stop"

$defaultServer = "http://localhost:3000"
$savedFile = Join-Path $PSScriptRoot "fenshenyun-player.conf"

if (Test-Path $savedFile) {
  $saved = Get-Content $savedFile -ErrorAction SilentlyContinue
  if ($saved.Count -ge 2) {
    $defaultServer = $saved[0]
    $defaultCode = $saved[1]
  }
}

Write-Host ""
Write-Host "分身云屏播 Windows 播放端" -ForegroundColor Cyan
Write-Host "用于 Windows 电脑连接电视/广告屏播放门店广告。"
Write-Host ""

$server = Read-Host "请输入控制台地址，直接回车使用 [$defaultServer]"
if ([string]::IsNullOrWhiteSpace($server)) {
  $server = $defaultServer
}
$server = $server.Trim().TrimEnd("/")

$codePrompt = "请输入屏幕码"
if ($defaultCode) {
  $codePrompt = "请输入屏幕码，直接回车使用 [$defaultCode]"
}
$code = Read-Host $codePrompt
if ([string]::IsNullOrWhiteSpace($code) -and $defaultCode) {
  $code = $defaultCode
}
$code = $code.Trim().ToUpper()

if ([string]::IsNullOrWhiteSpace($code)) {
  throw "屏幕码不能为空。请先在分身云屏播控制台添加播放设备，生成 6 位屏幕码。"
}

Set-Content -Path $savedFile -Value @($server, $code) -Encoding UTF8

$url = "$server/player/$code"
$edge = "C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"
$edge64 = "C:\Program Files\Microsoft\Edge\Application\msedge.exe"
$chrome = "C:\Program Files\Google\Chrome\Application\chrome.exe"
$chromeX86 = "C:\Program Files (x86)\Google\Chrome\Application\chrome.exe"

if (Test-Path $edge64) {
  Start-Process $edge64 -ArgumentList "--kiosk", $url, "--edge-kiosk-type=fullscreen", "--no-first-run"
} elseif (Test-Path $edge) {
  Start-Process $edge -ArgumentList "--kiosk", $url, "--edge-kiosk-type=fullscreen", "--no-first-run"
} elseif (Test-Path $chrome) {
  Start-Process $chrome -ArgumentList "--kiosk", $url, "--no-first-run"
} elseif (Test-Path $chromeX86) {
  Start-Process $chromeX86 -ArgumentList "--kiosk", $url, "--no-first-run"
} else {
  Start-Process $url
}

Write-Host ""
Write-Host "已打开播放地址：$url" -ForegroundColor Green
Write-Host "退出全屏可按 Alt + F4。"
